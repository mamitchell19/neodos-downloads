NeoDOS USB Creator for Windows
==============================

A small program that writes NeoDOS onto a USB stick, so you can start a PC or laptop from it.

How to use it
  1. Start NeoDOS-USB-Creator.exe. Windows asks "Do you want to allow this app to make changes?" - answer Yes
     (writing a whole stick needs that permission).
     The first time, Windows may show "Windows protected your PC", because the program is not signed by a
     company. Click "More info", then "Run anyway".
  2. Click "Download" to get the newest NeoDOS from the internet (about 16 MB, saved in your Downloads
     folder). If you already downloaded a NeoDOS-x.y-Live-USB.zip, the program finds it by itself (or click
     "Choose file..." - you can also drag the file onto the window; no need to unzip it). Either way it checks
     straight away that the download is complete and undamaged. If a newer NeoDOS is out than the file you
     have, it says so.
  3. Plug in the USB stick (at least 512 MB is a good size; everything on it is erased). It shows up in the
     list by itself. Choose it and click "Write NeoDOS". You are asked to confirm first.
  4. The program writes the stick, showing progress and the time left, then reads the whole stick back and
     compares it, so you know it was written correctly. Then you can pull the stick out.

Safety
  * Only USB drives are listed. Your computer's own disks (and the disk Windows runs from) never appear.
  * Large USB drives (over 300 GB - usually external hard disks with your backups on them) are hidden unless
    you tick "Show large USB drives".
  * The drive that holds the NeoDOS file, the drive the program runs from and write-protected sticks cannot
    be chosen.
  * Before anything is erased you see the stick's name, size, drive letters and label, and must confirm.

Starting a PC from the stick
  Plug it in, switch the PC on and press its boot-menu key straight away (F12 on ThinkPads and Dell; Esc,
  F8, F9 or F11 on others), then pick the USB stick. Secure Boot must be switched off in the PC's setup.
  More in LIVE-USB.txt, which comes with the NeoDOS download.

If something goes wrong
  The program says what happened in plain words. "Show details" opens its log file
  (%TEMP%\NeoDOS-USB-Creator.log), which helps when reporting a problem.
  The download comes from https://github.com/mamitchell19/neodos-downloads (the newest Release). If the
  connection drops, the program carries on where it stopped. If the PC cannot reach GitHub, download the
  zip there with a browser and choose it with "Choose file...".

Windows 7, 8, 10 and 11 (64-bit). Version 1.1. By Michael Mitchell.
